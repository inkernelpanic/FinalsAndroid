package com.example.myapplication

data class UserModel(
    var userId: String? = null,
    var userMail: String? = null,
    var userPass: String? = null,
    var userName: String? = null
)
